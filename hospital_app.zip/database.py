from flask_sqlalchemy import SQLAlchemy
from flask import Flask

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:123@localhost/Healthcare_Mgt'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


class Patients(db.Model):
    __tablename__ = 'patients'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    gender = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    blood_group = db.Column(db.String(20))
    patient_phone = db.Column(db.String(11), unique=True, nullable=False, index=True)
    next_of_kin = db.Column(db.String(100), nullable=False)
    presenting_complaint = db.Column(db.Text, nullable=False)
    admission_date = db.Column(db.Date, nullable=False)
    visits = db.relationship('Visits', backref='patients', lazy=True)


class Visits(db.Model):
    __tablename__ = 'visits'
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    diagnosis = db.Column(db.Text, nullable=False)
    tests = db.Column(db.Text)
    medication = db.Column(db.Text)
    next_appointment = db.Column(db.Date)
    attending_physician = db.Column(db.String(100), nullable=False)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'))


class Doctors(db.Model):
    __tablename__ = 'physicians'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    staff_id = db.Column(db.Integer, nullable=False)
    username = db.Column(db.String(100))
    password = db.Column(db.String(255), nullable=False)



class PatientLogin(db.Model):
    __tablename__ = 'patient_login'

    id = db.Column(db.Integer, primary_key=True, index=True)
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(11), nullable=False, unique=True)
    password = db.Column(db.String(255), nullable=False)


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print('Tables Successfully Created')




